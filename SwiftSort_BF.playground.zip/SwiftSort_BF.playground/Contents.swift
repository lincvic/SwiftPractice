//: Playground - noun: a place where people can play
//实验1:排序算法(BF)
import UIKit
func BF(a:String , b:String) -> Int{
    let target = a.components(separatedBy: "/")
    let find = b.components(separatedBy: "/")
    var i = 0
    var j = 0
    while i < target.count && j < find.count {
        
        if target[i] == find[j] {
            i += 1
            j += 1
        }else {
            i = i - j + 1
            j = 0
        }
    }
    if j == find.count {
        return i - j
        
    }else{
        return -10 //返回-10则为失败
        
    }
}
var target = "a/b/a/b/s/s/c/c/a/a/b/b/c/c/a/a/s/s"
var find = "b/b/c/c"
var location = BF(a: target, b: find)
print("目标\(find)\n在主串\(target)中\n位置是\(location)")



