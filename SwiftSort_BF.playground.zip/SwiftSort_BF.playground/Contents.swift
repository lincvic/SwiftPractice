//: Playground - noun: a place where people can play
//实验1:排序算法(BF)
import UIKit
func BF(a:String , b:String) -> Int{
    let target = Array(a)
    let find = Array(b)
    var i = 0
    var j = 0
    while i < target.count && j < find.count {
        
        if target[i] == find[j] {
            i += 1
            j += 1
        }else {
            i = i - j + 1
            j = 0
        }
    }
    if j == find.count {
        return i - j
        
    }else{
        return -10
        
    }
}
var target = "aabssccaabbccass"
var find = "bbcc"
var location = BF(a: target, b: find)
print("目标\(find)\n在主串\(target)中\n位置是\(location)")



