//: Playground - noun: a place where people can play
//各类排序
import UIKit
//全部排序的协议
protocol Type {
    func sort(items: Array<Int>) -> Array<Int>
}
//冒泡排序
class 冒泡排序: Type {
    func sort(items: Array<Int>) -> Array<Int> {
        var sortArray = items
        for i in 0..<sortArray.count{
            var j = sortArray.count - 1
            while j > i {
                if sortArray[j-1] > sortArray[j]{
                    let temp = sortArray[j]
                    sortArray[j] = sortArray[j-1]
                    sortArray[j-1] = temp
                }
                j -= 1
            }
        
    }
        return sortArray
}
}
var BubbleSort = 冒泡排序();
var array = [1,22,12,33,2,3,44,13]
print("串\(array)\n冒泡排序的结果为：\(BubbleSort.sort(items: array))\n")
//选择排序
class 选择排序:Type {
    func sort(items: Array<Int>) -> Array<Int> {
        var sortArray = items
        for i in 0..<sortArray.count {
            var j = i + 1
            var minValue = sortArray[i]
            var min = i
            while j < sortArray.count {
                if minValue > sortArray[j] {
                    minValue = sortArray[j]
                    min = j
                }
                j += 1
            }
            if min != 1 {
                let temp = sortArray[i]
                sortArray[i] = sortArray[min]
                sortArray[min] = temp
            }
        }
        return sortArray
    }
}
var selectSort = 选择排序();
var array_ = [1,22,12,33,2,3,44,13]
print("串\(array_)\n选择排序的结果为\(selectSort.sort(items: array_))\n")
