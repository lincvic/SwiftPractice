//: Playground - noun: a place where people can play

import UIKit
//推导类型
var str = "Hello, playground"
var Zero = 0
print("Zero is \(Zero)")
//字符串相加
var str2 = str + "!"
print("\(str2)")
//遍历
var List = ["A","B","C","D"]
for Character in List{
    print("\(Character)")
}
print("\n")
var numList = ["1","2","3"]
for NSNumber in numList{
    print("\(NSNumber)")
}
print("\n")
List[1...3] = ["b","c","d"]
for Character in List{
    print("\(Character)")
}
//无遍历中介遍历
var count = 0
for _ in 1...100{
    count += 1
}
print("\(count)")
//Append
List += ["E"]
//字典
var 字典 = ["1":"1⃣️","2":"2⃣️","3":"3⃣️"]
字典["1"]

//类及算值
class Drink{
    var brand = "红牛"
    var price = 10.0
    //函数
    func 获取品牌及价格() {
        print("品牌为\(brand),价格为\(price)")
    }
    //算值
    var 算值获取品牌及价格: String{
        return "品牌为\(brand)，价格为\(price)"
    }
    func  重置品牌名称(name: String) {
        brand = name
    }
    func  重置饮料价格(price_: Double) {
        price = price_
    }
    
}
var drink = Drink()
print(drink.算值获取品牌及价格)
drink.重置品牌名称(name: "脉动")
drink.重置饮料价格(price_: 5.0)
print(drink.算值获取品牌及价格)
//继承，初始化
class cestbon: Drink{
    override init() {
        super.init()
        brand = "怡宝"
        price = 2.0
    }

}
var waterDrink = cestbon()
print(waterDrink.获取品牌及价格())
//属性观察
class vita: Drink {
    override var price: Double{
        willSet{
            if newValue > 10{
                print("价格过高")
            }
        }
        didSet{
            if oldValue < 1 {
                print("曾经的价格过低")
            }
        }
    }
}
var lemon = vita()
lemon.price = 11





