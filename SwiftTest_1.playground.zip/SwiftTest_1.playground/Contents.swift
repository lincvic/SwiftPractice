//: Playground - noun: a place where people can play

import UIKit
//推导类型
var str = "Hello, playground"
var Zero = 0
print("Zero is \(Zero)")
//字符串相加
var str2 = str + "!"
print("\(str2)")
//遍历
var List = ["A","B","C","D"]
for Character in List{
    print("\(Character)")
}
print("\n")
var numList = ["1","2","3"]
for NSNumber in numList{
    print("\(NSNumber)")
}
print("\n")
List[1...3] = ["b","c","d"]
for Character in List{
    print("\(Character)")
}
//append
List += ["E"]
//字典
var 字典 = ["1":"1⃣️","2":"2⃣️","3":"3⃣️"]
字典["1"]


